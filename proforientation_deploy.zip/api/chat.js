// Serverless proxy for the "Компас" app.
// Keeps ANTHROPIC_API_KEY on the server — it must never appear in browser-side JS.
// Works as-is on Vercel (Node serverless function). For Netlify/Cloudflare Workers
// the request/response objects differ slightly — see README.md for notes.

const ALLOWED_MODEL = "claude-sonnet-5"; // swap to "claude-haiku-4-5-20251001" for a cheaper/faster assistant
const MAX_TOKENS_CAP = 800;             // hard ceiling so a public endpoint can't be abused into huge bills

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ error: "method_not_allowed" });
    return;
  }

  try {
    const { messages, system, max_tokens } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0) {
      res.status(400).json({ error: "messages_required" });
      return;
    }

    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: ALLOWED_MODEL,
        max_tokens: Math.min(Number(max_tokens) || 700, MAX_TOKENS_CAP),
        system,
        messages
      })
    });

    const data = await anthropicRes.json();
    res.status(anthropicRes.status).json(data);
  } catch (err) {
    res.status(500).json({ error: "proxy_failed" });
  }
};
